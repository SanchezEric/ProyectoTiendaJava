/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function prue()
{
    alert("funcionaaa!!!");
}
function toadmin()
{
    window.location.href = "formAdmin.jsp";
}
function toregistrouser()
{
    window.location.href = "formRegistro.jsp";
}
function ToLogout(){
    window.location.href = "Logout";
}
function Tobajauser(){
    alert("Vas a deshabilitar tu user, contacta con el administrador!!!");
    window.location.href = "bajaUser";
}
function tomostrarcli(){
    window.location.href = "mostrarClientes.jsp";
}
function toindex(){
    window.location.href = "index.jsp";
}
function tomenuadmin(){
    window.location.href = "menuAdministrador.jsp";
}
/////////////////// VALIDAR FORMULARIO DE REGISTRO USUARIO ///////////////////
function validacionReUser()
{
    
}