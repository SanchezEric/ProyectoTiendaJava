/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectotienda.modelo;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import proyectotienda.modelo.Lineafactura;

/**
 *
 * @author Eric
 */
@Entity
public class Factura extends Conexion implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_factura")
    private Integer idFactura;
    @Basic(optional = false)
    @Column(name = "fecha_factura")
    @Temporal(TemporalType.DATE)
    private Date fechaFactura;
    @Basic(optional = false)
    @Column(name = "total_factura")
    private long totalFactura;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idFactura")
    private Collection<Lineafactura> LineafacturaCollection;
    @JoinColumn(name = "id_cliente", referencedColumnName = "id_cliente")
    @ManyToOne(optional = false)
    private Cliente idCliente;
    
    //CONSTRUCTOR

    public Factura() {
    }

    public Factura(Integer idFactura) {
        this.idFactura = idFactura;
    }

    public Factura(Integer idFactura, Date fechaFactura, long totalFactura, Collection<Lineafactura> tblLineafacturaCollection, Cliente idCliente) {
        this.idFactura = idFactura;
        this.fechaFactura = fechaFactura;
        this.totalFactura = totalFactura;
        this.LineafacturaCollection = tblLineafacturaCollection;
        this.idCliente = idCliente;
    }
    
    //GETTERS SETTERS

    public Integer getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(Integer idFactura) {
        this.idFactura = idFactura;
    }

    public Date getFechaFactura() {
        return fechaFactura;
    }

    public void setFechaFactura(Date fechaFactura) {
        this.fechaFactura = fechaFactura;
    }

    public long getTotalFactura() {
        return totalFactura;
    }

    public void setTotalFactura(long totalFactura) {
        this.totalFactura = totalFactura;
    }

    public Collection<Lineafactura> getLineafacturaCollection() {
        return LineafacturaCollection;
    }

    public void setTblLineafacturaCollection(Collection<Lineafactura> LineafacturaCollection) {
        this.LineafacturaCollection = LineafacturaCollection;
    }

    public Cliente getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Cliente idCliente) {
        this.idCliente = idCliente;
    }
    
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
