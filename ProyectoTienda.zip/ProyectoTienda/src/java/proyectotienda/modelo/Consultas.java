/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectotienda.modelo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
/**
 *
 * @author Eric
 */
public class Consultas extends Conexion{
    
    
    
    public boolean Autenticacion(String user,String pass) throws SQLException
    {
        Statement st = con.createStatement();
        ResultSet rs = null;
        String Consulta = "Select * from tbl_cliente";
        rs = st.executeQuery(Consulta);
        
        while(rs.next())
        {
            if(user.equals(rs.getString("mail_cliente")) && pass.equals(rs.getString("pwd_cliente")))
                return true;
        }
  
        return false;
    }
    /**
     * Prueba Consulta Login
    public static void main(String[] args) throws SQLException {
        Consultas con = new Consultas();
        System.out.println(con.Autenticacion("Eric", "123"));
    }
    
    **/
     public boolean AutenticacionAdmin(String user,String pass) throws SQLException
    {
        Statement st = con.createStatement();
        ResultSet rs = null;
        String Consulta = "Select * from tbl_administrador";
        rs = st.executeQuery(Consulta);
        
        while(rs.next())
        {
            if(user.equals(rs.getString("mail_admin")) && pass.equals(rs.getString("pwd_admin")))
                return true;
        }
  
        return false;
    }
     
       
       /**
     * Prueba Consulta loginAdmin
    public static void main(String[] args) throws SQLException {
        Consultas con = new Consultas();
        System.out.println(con.AutenticacionAdmin("Admin", "123"));
    }
    * 
     * @param mailCliente
     * @return 
     * @throws java.sql.SQLException
      **/
/**
       public boolean ComprobarMail(String mailCliente) throws SQLException {
       
            Statement st = con.createStatement();
            ResultSet rs = null;
            String sqlComprobarMail = "select mail_cliente FROM tbl_cliente";
            rs = st.executeQuery(sqlComprobarMail);
         while(rs.next())
        {
            if(mailCliente.equals(rs.getString("mail_cliente"))){
                return true;
            }
        }
  
        return false;
    }

**/
        
       
        /**
         * 
        Comprobar existe el mail de usuario
           public static void main(String[] args) throws SQLException {
        Consultas con = new Consultas();
        System.out.println(con.ComprobarMail("v"));
           }
     * @param usaurioCliente
     * @param nomCliente
     * @param apellidoCliente
     * @param mailCliente
     * @param pwdCliente
     * @param nifCliente
     * @param cpostalCliente
     * @param direccionCliente
     * @return 
     * @throws java.sql.SQLException 
           
       
    public boolean Registrousuario(String usaurioCliente, String nomCliente, String apellidoCliente, String mailCliente, String pwdCliente, String nifCliente, String cpostalCliente, String direccionCliente)throws SQLException {
            
            int filasAfectadas = 0;
        String sql = "INSERT INTO tbl_cliente (usaurio_cliente, nom_cliente, apellido_cliente, mail_cliente, pwd_cliente, nif_cliente, cpostal_cliente, direccion_cliente) VALUES('"+ usaurioCliente + "','" + nomCliente + "','" + apellidoCliente + "','" + mailCliente + "','" + pwdCliente + "','" + nifCliente + "','" + cpostalCliente + "','" + direccionCliente + "')";
        Statement st = con.createStatement();
        filasAfectadas = st.executeUpdate(sql);
            return filasAfectadas != 0;
 
        
    }
    */
       /**
       
       
    public boolean Registrousuario(String usaurioCliente, String nomCliente, String apellidoCliente, String mailCliente, String pwdCliente, String nifCliente, String cpostalCliente, String direccionCliente) throws SQLException{
        PreparedStatement pst = null;
        String sql = "INSERT INTO tbl_cliente (usaurio_cliente, nom_cliente, apellido_cliente, mail_cliente, pwd_cliente, nif_cliente, cpostal_cliente, direccion_cliente) value(?,?,?,?,?,?,?,?) ";
        pst =con.prepareStatement(sql);
        
        
         
         
         
         
         
         
         
         
          return false;
    }

       
       
       
       
       
   
        public static void main(String[] args) throws SQLException {
        Consultas con = new Consultas();
        System.out.println(con.Registrousuario("usuario", "nombre", "apellido", "mail", "passw", "nif", "08906", "direc"));
        }
       **/ 
}



     
     
     
     
     
     
     
     
