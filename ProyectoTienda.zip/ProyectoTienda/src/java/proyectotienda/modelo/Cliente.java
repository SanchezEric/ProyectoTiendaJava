/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectotienda.modelo;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static org.eclipse.persistence.platform.database.oracle.plsql.OraclePLSQLTypes.Int;
@Entity
public class Cliente extends Conexion implements Serializable{

    @Id
   private Integer idCliente;
    @Basic(optional = false)
    @Column(name = "usaurio_cliente")
    private String usaurioCliente;
    @Basic(optional = false)
    @Column(name = "nom_cliente")
    private String nomCliente;
    @Basic(optional = false)
    @Column(name = "apellido_cliente")
    private String apellidoCliente;
    @Basic(optional = false)
    @Column(name = "mail_cliente")
    private String mailCliente;
    @Basic(optional = false)
    @Column(name = "pwd_cliente")
    private String pwdCliente;
    @Basic(optional = false)
    @Column(name = "nif_cliente")
    private String nifCliente;
    @Basic(optional = false)
    @Column(name = "cpostal_cliente")
    private String cpostalCliente;
    @Basic(optional = false)
    @Column(name = "direccion_cliente")
    private String direccionCliente;
    @Basic(optional = false)
    @Column(name = "activo_cliente")
    private String activoCliente;

    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public Cliente() {
    }

    public Cliente(Integer idCliente) {
        this.idCliente = idCliente;
    }
    
    
    
    public Cliente(Integer idCliente, String usaurioCliente, String nomCliente, String apellidoCliente, String mailCliente, String pwdCliente, String nifCliente, String cpostalCliente, String direccionCliente, String activoCliente) {
        this.idCliente = idCliente;
        this.usaurioCliente = usaurioCliente;
        this.nomCliente = nomCliente;
        this.apellidoCliente = apellidoCliente;
        this.mailCliente = mailCliente;
        this.pwdCliente = pwdCliente;
        this.nifCliente = nifCliente;
        this.cpostalCliente = cpostalCliente;
        this.direccionCliente = direccionCliente;
        this.activoCliente = activoCliente;
    }

    public String getUsaurioCliente() {
        return usaurioCliente;
    }

    public void setUsaurioCliente(String usaurioCliente) {
        this.usaurioCliente = usaurioCliente;
    }

    public String getNomCliente() {
        return nomCliente;
    }

    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }

    public String getApellidoCliente() {
        return apellidoCliente;
    }

    public void setApellidoCliente(String apellidoCliente) {
        this.apellidoCliente = apellidoCliente;
    }

    public String getMailCliente() {
        return mailCliente;
    }

    public void setMailCliente(String mailCliente) {
        this.mailCliente = mailCliente;
    }

    public String getPwdCliente() {
        return pwdCliente;
    }

    public void setPwdCliente(String pwdCliente) {
        this.pwdCliente = pwdCliente;
    }

    public String getNifCliente() {
        return nifCliente;
    }

    public void setNifCliente(String nifCliente) {
        this.nifCliente = nifCliente;
    }

    public String getCpostalCliente() {
        return cpostalCliente;
    }

    public void setCpostalCliente(String cpostalCliente) {
        this.cpostalCliente = cpostalCliente;
    }

    public String getDireccionCliente() {
        return direccionCliente;
    }

    public void setDireccionCliente(String direccionCliente) {
        this.direccionCliente = direccionCliente;
    }

    public String getActivoCliente() {
        return activoCliente;
    }

    public void setActivoCliente(String activoCliente) {
        this.activoCliente = activoCliente;
    }
    
    
    ////Metodos
        //Comprobar si el Mail esta repetido
    
           public boolean ComprobarMail(Cliente ai) throws SQLException {
       
            Statement st = con.createStatement();
            ResultSet rs = null;
            String sqlComprobarMail = "select mail_cliente FROM tbl_cliente";
            rs = st.executeQuery(sqlComprobarMail);
         while(rs.next())
        {
            if(mailCliente.equals(rs.getString("mail_cliente"))){
                return true;
            }
        }
  
        return false;
    }
           
           
           
           ///InsertarUsuario
           
           
       public boolean Registrousuario(Cliente ai)throws SQLException {
            
            int filasAfectadas = 0;
            String sql = "INSERT INTO tbl_cliente (usaurio_cliente, nom_cliente, apellido_cliente, mail_cliente, pwd_cliente, nif_cliente, cpostal_cliente, direccion_cliente) VALUES('"+ usaurioCliente + "','" + nomCliente + "','" + apellidoCliente + "','" + mailCliente + "','" + pwdCliente + "','" + nifCliente + "','" + cpostalCliente + "','" + direccionCliente + "')";
            Statement st = con.createStatement();
            filasAfectadas = st.executeUpdate(sql);
            return filasAfectadas != 0; 
    }
    
    //LOGIN CLIENTE
    public boolean Autenticacion(Cliente ai) throws SQLException
    {
        Statement st = con.createStatement();
        ResultSet rs = null;
        String Consulta = "Select * from tbl_cliente";
        rs = st.executeQuery(Consulta);
        
        while(rs.next())
        {
            if(mailCliente.equals(rs.getString("mail_cliente")) && pwdCliente.equals(rs.getString("pwd_cliente"))){
                
                
                
            
                
                return true;
        
        }      
    } 
       return false;
    }
    
    
    ///Metodo para comprobar usuario ACT
    public boolean usuarioact(Cliente ai) throws SQLException{
        Statement st = con.createStatement();
        ResultSet rs = null;
        String Consulta = "Select * from tbl_cliente";
        rs = st.executeQuery(Consulta);
                while(rs.next())
        {
        if( mailCliente.equals(rs.getString("mail_cliente")) && rs.getString("activo_cliente").equals("true")) {
            
           return true;
        }
        }
        return false;
    }
    
 
    /////////Baja usuario
    public boolean bajausuario(String usuario) throws SQLException{
        int filasAfectadas = 0;
        String sql = "UPDATE tbl_cliente SET activo_cliente='false' WHERE mail_cliente='" + usuario + "'"; 
        Statement st = con.createStatement();
        filasAfectadas = st.executeUpdate(sql);
        return filasAfectadas != 0; 
        
    }
    
    
    /////////////Mostrar clientes
    public void mostrar (ArrayList lista) throws SQLException{
    String sql = "Select * FROM tbl_cliente";
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery(sql);
    while(rs.next()){
        Cliente ai = new Cliente();
        ai.setIdCliente(rs.getInt("id_cliente"));
        ai.setUsaurioCliente(rs.getString("usaurio_cliente"));
        ai.setMailCliente(rs.getString("mail_cliente"));
        ai.setActivoCliente(rs.getString("activo_cliente"));
        lista.add(ai);
       
    }
    
    
    
    
    
    
    }
    
    
    
    
    
    
  
    
}
           
           
     
                      