/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectotienda.modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author Eric
 */
@Entity
public class Lineafactura implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_lineaFactura")
    private Integer idlineaFactura;
    @Basic(optional = false)
    @Column(name = "cantidad_lineafactura")
    private int cantidadLineafactura;
    @Basic(optional = false)
    @Column(name = "total_lineafactura")
    private long totalLineafactura;
    @JoinColumn(name = "id_factura", referencedColumnName = "id_factura")
    @ManyToOne(optional = false)
    private Factura idFactura;
    @JoinColumn(name = "id_producto", referencedColumnName = "id_producto")
    @ManyToOne(optional = false)
    private Producto idProducto;
    
    //Constructores

    public Lineafactura() {
    }

    public Lineafactura(Integer idlineaFactura) {
        this.idlineaFactura = idlineaFactura;
    }

    public Lineafactura(Integer idlineaFactura, int cantidadLineafactura, long totalLineafactura, Factura idFactura, Producto idProducto) {
        this.idlineaFactura = idlineaFactura;
        this.cantidadLineafactura = cantidadLineafactura;
        this.totalLineafactura = totalLineafactura;
        this.idFactura = idFactura;
        this.idProducto = idProducto;
    }
    
     //GETTERS AND SETTERS

    public Integer getIdlineaFactura() {
        return idlineaFactura;
    }

    public void setIdlineaFactura(Integer idlineaFactura) {
        this.idlineaFactura = idlineaFactura;
    }

    public int getCantidadLineafactura() {
        return cantidadLineafactura;
    }

    public void setCantidadLineafactura(int cantidadLineafactura) {
        this.cantidadLineafactura = cantidadLineafactura;
    }

    public long getTotalLineafactura() {
        return totalLineafactura;
    }

    public void setTotalLineafactura(long totalLineafactura) {
        this.totalLineafactura = totalLineafactura;
    }

    public Factura getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(Factura idFactura) {
        this.idFactura = idFactura;
    }

    public Producto getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Producto idProducto) {
        this.idProducto = idProducto;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
