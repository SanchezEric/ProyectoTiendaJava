/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectotienda.modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Eric
 */
@Entity
public class Producto extends Conexion implements Serializable {
 @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_producto")
    private Integer idProducto;
    @Basic(optional = false)
    @Column(name = "nom_product")
    private String nomProduct;
    @Basic(optional = false)
    @Column(name = "desc_product")
    private String descProduct;
    @Basic(optional = false)
    @Column(name = "stock_product")
    private int stockProduct;
    @Column(name = "descuento_product")
    private Integer descuentoProduct;
    @Basic(optional = false)
    @Column(name = "precio_product")
    private long precioProduct;
    @Basic(optional = false)
    @Column(name = "activo_product")
    private boolean activoProduct;
    @Basic(optional = false)
    @Column(name = "tipo_product")
    private String tipoProduct;
    @Basic(optional = false)
    @Column(name = "img_product")
    private String imgProduct;

    
    ////Constructores
    public Producto() {
    }

    public Producto(Integer idProducto) {
        this.idProducto = idProducto;
    }

    public Producto(Integer idProducto, String nomProduct, String descProduct, int stockProduct, Integer descuentoProduct, long precioProduct, boolean activoProduct, String tipoProduct, String imgProduct) {
        this.idProducto = idProducto;
        this.nomProduct = nomProduct;
        this.descProduct = descProduct;
        this.stockProduct = stockProduct;
        this.descuentoProduct = descuentoProduct;
        this.precioProduct = precioProduct;
        this.activoProduct = activoProduct;
        this.tipoProduct = tipoProduct;
        this.imgProduct = imgProduct;
    }

    //GETTERS y SETTERS
    public Integer getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(Integer idProducto) {
        this.idProducto = idProducto;
    }

    public String getNomProduct() {
        return nomProduct;
    }

    public void setNomProduct(String nomProduct) {
        this.nomProduct = nomProduct;
    }

    public String getDescProduct() {
        return descProduct;
    }

    public void setDescProduct(String descProduct) {
        this.descProduct = descProduct;
    }

    public int getStockProduct() {
        return stockProduct;
    }

    public void setStockProduct(int stockProduct) {
        this.stockProduct = stockProduct;
    }

    public Integer getDescuentoProduct() {
        return descuentoProduct;
    }

    public void setDescuentoProduct(Integer descuentoProduct) {
        this.descuentoProduct = descuentoProduct;
    }

    public long getPrecioProduct() {
        return precioProduct;
    }

    public void setPrecioProduct(long precioProduct) {
        this.precioProduct = precioProduct;
    }

    public boolean isActivoProduct() {
        return activoProduct;
    }

    public void setActivoProduct(boolean activoProduct) {
        this.activoProduct = activoProduct;
    }

    public String getTipoProduct() {
        return tipoProduct;
    }

    public void setTipoProduct(String tipoProduct) {
        this.tipoProduct = tipoProduct;
    }

    public String getImgProduct() {
        return imgProduct;
    }

    public void setImgProduct(String imgProduct) {
        this.imgProduct = imgProduct;
    }
    
    
    
    





}