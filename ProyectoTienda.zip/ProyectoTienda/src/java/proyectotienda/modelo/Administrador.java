/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectotienda.modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Eric
 */
@Entity
public class Administrador extends Conexion implements Serializable {


    @Id
    @Column(name = "id_admin")
    private Integer idAdmin;
    @Basic(optional = false)
    @Column(name = "user_admin")
    private String userAdmin;
    @Basic(optional = false)
    @Column(name = "mail_admin")
    private String mailAdmin;
    @Basic(optional = false)
    @Column(name = "pwd_admin")
    private String pwdAdmin;
    @Basic(optional = false)
    @Column(name = "desc_admin")
    private String descAdmin;
    @Basic(optional = false)
    @Column(name = "nom_admin")
    private String nomAdmin;
    @Basic(optional = false)
    @Column(name = "apellido_admin")
    private String apellidoAdmin;
    @Basic(optional = false)
    @Column(name = "activo_admin")
    private boolean activoAdmin;

    
    
    ///Constructores
    public Administrador() {
    }

    public Administrador(Integer idAdmin) {
        this.idAdmin = idAdmin;
    }

    public Administrador(Integer idAdmin, String userAdmin, String mailAdmin, String pwdAdmin, String descAdmin, String nomAdmin, String apellidoAdmin, boolean activoAdmin) {
        this.idAdmin = idAdmin;
        this.userAdmin = userAdmin;
        this.mailAdmin = mailAdmin;
        this.pwdAdmin = pwdAdmin;
        this.descAdmin = descAdmin;
        this.nomAdmin = nomAdmin;
        this.apellidoAdmin = apellidoAdmin;
        this.activoAdmin = activoAdmin;
    }
    
    //GETTERS SETTERS 

    public Integer getIdAdmin() {
        return idAdmin;
    }

    public void setIdAdmin(Integer idAdmin) {
        this.idAdmin = idAdmin;
    }

    public String getUserAdmin() {
        return userAdmin;
    }

    public void setUserAdmin(String userAdmin) {
        this.userAdmin = userAdmin;
    }

    public String getMailAdmin() {
        return mailAdmin;
    }

    public void setMailAdmin(String mailAdmin) {
        this.mailAdmin = mailAdmin;
    }

    public String getPwdAdmin() {
        return pwdAdmin;
    }

    public void setPwdAdmin(String pwdAdmin) {
        this.pwdAdmin = pwdAdmin;
    }

    public String getDescAdmin() {
        return descAdmin;
    }

    public void setDescAdmin(String descAdmin) {
        this.descAdmin = descAdmin;
    }

    public String getNomAdmin() {
        return nomAdmin;
    }

    public void setNomAdmin(String nomAdmin) {
        this.nomAdmin = nomAdmin;
    }

    public String getApellidoAdmin() {
        return apellidoAdmin;
    }

    public void setApellidoAdmin(String apellidoAdmin) {
        this.apellidoAdmin = apellidoAdmin;
    }

    public boolean isActivoAdmin() {
        return activoAdmin;
    }

    public void setActivoAdmin(boolean activoAdmin) {
        this.activoAdmin = activoAdmin;
    }
    
    //Metodos
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
