/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectotienda.modelo;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Eric
 */
@Entity
public class Administrador extends Conexion implements Serializable {


    @Id
    @Column(name = "id_admin")
    private Integer idAdmin;
    @Basic(optional = false)
    @Column(name = "user_admin")
    private String userAdmin;
    @Basic(optional = false)
    @Column(name = "mail_admin")
    private String mailAdmin;
    @Basic(optional = false)
    @Column(name = "pwd_admin")
    private String pwdAdmin;
    @Basic(optional = false)
    @Column(name = "desc_admin")
    private String descAdmin;
    @Basic(optional = false)
    @Column(name = "nom_admin")
    private String nomAdmin;
    @Basic(optional = false)
    @Column(name = "apellido_admin")
    private String apellidoAdmin;
    @Basic(optional = false)
    @Column(name = "activo_admin")
    private String activoAdmin;

    
    
    ///Constructores
    public Administrador() {
    }

    public Administrador(Integer idAdmin) {
        this.idAdmin = idAdmin;
    }

    public Administrador(Integer idAdmin, String userAdmin, String mailAdmin, String pwdAdmin, String descAdmin, String nomAdmin, String apellidoAdmin, String activoAdmin) {
        this.idAdmin = idAdmin;
        this.userAdmin = userAdmin;
        this.mailAdmin = mailAdmin;
        this.pwdAdmin = pwdAdmin;
        this.descAdmin = descAdmin;
        this.nomAdmin = nomAdmin;
        this.apellidoAdmin = apellidoAdmin;
        this.activoAdmin = activoAdmin;
    }
    
    //GETTERS 

    public Integer getIdAdmin() {
        return idAdmin;
    }

    public String getUserAdmin() {
        return userAdmin;
    }

    public String getMailAdmin() {
        return mailAdmin;
    }

    public String getPwdAdmin() {
        return pwdAdmin;
    }

    public String getDescAdmin() {
        return descAdmin;
    }

    public String getNomAdmin() {
        return nomAdmin;
    }

    public String getApellidoAdmin() {
        return apellidoAdmin;
    }

    public String isActivoAdmin() {
        return activoAdmin;
    }

//SETTERS

    public void setIdAdmin(Integer idAdmin) {
        this.idAdmin = idAdmin;
    }

    public void setUserAdmin(String userAdmin) {
        this.userAdmin = userAdmin;
    }

    public void setMailAdmin(String mailAdmin) {
        this.mailAdmin = mailAdmin;
    }

    public void setPwdAdmin(String pwdAdmin) {
        this.pwdAdmin = pwdAdmin;
    }

    public void setDescAdmin(String descAdmin) {
        this.descAdmin = descAdmin;
    }

    public void setNomAdmin(String nomAdmin) {
        this.nomAdmin = nomAdmin;
    }

    public void setApellidoAdmin(String apellidoAdmin) {
        this.apellidoAdmin = apellidoAdmin;
    }

    public void setActivoAdmin(String activoAdmin) {
        this.activoAdmin = activoAdmin;
    }
    
    
    
    
    /////////////////////////////////////////////////////////////////////////////////
    //Metodos
    
    //Comprueba si existe el usuario
     public boolean Autenticacion(Administrador ai) throws SQLException
    {
        Statement st = con.createStatement();
        ResultSet rs = null;
        String Consulta = "Select * from tbl_administrador";
        rs = st.executeQuery(Consulta);
        
        while(rs.next())
        {
            if(mailAdmin.equals(rs.getString("mail_admin")) && pwdAdmin.equals(rs.getString("pwd_admin"))){
   
                return true;
        }      
    } 
       return false;
    }
    
    /// Comprueba si el usuario esta activo
        public boolean usuarioact(Administrador ai) throws SQLException{
        Statement st = con.createStatement();
        ResultSet rs = null;
        String Consulta = "Select * from tbl_administrador";
        rs = st.executeQuery(Consulta);
                while(rs.next())
        {
        if( mailAdmin.equals(rs.getString("mail_admin")) && rs.getString("activo_admin").equals("true")) {
            
           return true;
        }
        }
        return false;
    }
    
    
    
    
    
    
    
    
    
    
    
    
}
